const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-claim')
    .setDescription('Configure the ticket claim system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('enable')
        .setDescription('Require claiming before staff can talk in a ticket (uses roles set via /ticket-staff)'))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Disable the claim requirement (staff can talk in any open ticket)')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'enable') {
      if (!data.ticket.staffRoleIds.length) {
        return interaction.reply({ content: '⚠️ No ticket staff roles are configured yet. Add at least one with `/ticket-staff add` first.', ephemeral: true });
      }
      data.ticket.claim.enabled = true;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({
        content: '✅ Ticket claiming enabled.\n• Ticket staff can see new tickets but can\'t send messages until one of them hits **Claim**.\n• Once claimed, only that person can talk — other staff stay muted in that ticket.',
        ephemeral: true,
      });
    }

    if (sub === 'disable') {
      data.ticket.claim.enabled = false;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '🚫 Ticket claiming disabled. Ticket staff can talk freely in any open ticket.', ephemeral: true });
    }
  },
};
