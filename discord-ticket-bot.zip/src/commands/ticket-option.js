const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

const MAX_OPTIONS = 25; // Discord select menu limit

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-option')
    .setDescription('Manage the dropdown options used by "Sidebar Open" ticket panels')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add an option to the sidebar menu')
        .addStringOption(opt => opt.setName('label').setDescription('Text shown in the dropdown, e.g. "Billing Support"').setRequired(true))
        .addChannelOption(opt => opt.setName('category').setDescription('Category tickets from this option are created in').setRequired(true).addChannelTypes(ChannelType.GuildCategory))
        .addStringOption(opt => opt.setName('description').setDescription('Short description shown under the label in the dropdown'))
        .addStringOption(opt => opt.setName('emoji').setDescription('Emoji shown next to the label')))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a sidebar option by its label')
        .addStringOption(opt => opt.setName('label').setDescription('Exact label of the option to remove').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all configured sidebar options')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'add') {
      if (data.ticket.sidebarOptions.length >= MAX_OPTIONS) {
        return interaction.reply({ content: `⚠️ You already have the maximum of ${MAX_OPTIONS} sidebar options (Discord's dropdown limit).`, ephemeral: true });
      }
      const label = interaction.options.getString('label');
      if (data.ticket.sidebarOptions.some(o => o.label.toLowerCase() === label.toLowerCase())) {
        return interaction.reply({ content: `⚠️ An option labeled "${label}" already exists.`, ephemeral: true });
      }
      const category = interaction.options.getChannel('category');
      const description = interaction.options.getString('description') || null;
      const emoji = interaction.options.getString('emoji') || null;

      data.ticket.sidebarOptions.push({ label, description, emoji, categoryId: category.id });
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: `✅ Added sidebar option **${label}** → ${category}.`, ephemeral: true });
    }

    if (sub === 'remove') {
      const label = interaction.options.getString('label');
      const before = data.ticket.sidebarOptions.length;
      data.ticket.sidebarOptions = data.ticket.sidebarOptions.filter(o => o.label.toLowerCase() !== label.toLowerCase());
      saveGuildData(interaction.guildId, data);
      if (before === data.ticket.sidebarOptions.length) {
        return interaction.reply({ content: `⚠️ No option labeled "${label}" was found.`, ephemeral: true });
      }
      return interaction.reply({ content: `🗑️ Removed sidebar option **${label}**.`, ephemeral: true });
    }

    if (sub === 'list') {
      if (!data.ticket.sidebarOptions.length) {
        return interaction.reply({ content: 'No sidebar options configured yet. Use `/ticket-option add`.', ephemeral: true });
      }
      const lines = data.ticket.sidebarOptions.map((o, i) => `${i + 1}. **${o.label}**${o.emoji ? ` ${o.emoji}` : ''} → <#${o.categoryId}>${o.description ? ` — _${o.description}_` : ''}`);
      return interaction.reply({ content: lines.join('\n'), ephemeral: true });
    }
  },
};
