const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

const MAX_QUESTIONS = 5; // Discord modal limit (5 text inputs per modal)

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-form')
    .setDescription('Manage the questions asked by "Form Open" ticket panels')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a question to the form (max 5)')
        .addStringOption(opt => opt.setName('question').setDescription('The question text').setRequired(true))
        .addStringOption(opt =>
          opt.setName('style').setDescription('Short (one line) or Paragraph (multi-line) answer')
            .addChoices({ name: 'Short answer', value: 'short' }, { name: 'Paragraph', value: 'paragraph' }))
        .addBooleanOption(opt => opt.setName('required').setDescription('Must the user answer this to open a ticket? (default: yes)'))
        .addStringOption(opt => opt.setName('placeholder').setDescription('Example/placeholder text shown in the empty field')))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a question by its position number')
        .addIntegerOption(opt => opt.setName('index').setDescription('Position shown in /ticket-form list').setRequired(true).setMinValue(1)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List the current form questions'))
    .addSubcommand(sub =>
      sub.setName('clear')
        .setDescription('Remove all form questions')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'add') {
      if (data.ticket.formQuestions.length >= MAX_QUESTIONS) {
        return interaction.reply({ content: `⚠️ You already have the maximum of ${MAX_QUESTIONS} questions (Discord's form limit).`, ephemeral: true });
      }
      const question = interaction.options.getString('question');
      const style = interaction.options.getString('style') || 'short';
      const required = interaction.options.getBoolean('required') ?? true;
      const placeholder = interaction.options.getString('placeholder') || null;

      data.ticket.formQuestions.push({ question, style, required, placeholder });
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: `✅ Added question ${data.ticket.formQuestions.length}/${MAX_QUESTIONS}: "${question}"`, ephemeral: true });
    }

    if (sub === 'remove') {
      const index = interaction.options.getInteger('index') - 1;
      if (index < 0 || index >= data.ticket.formQuestions.length) {
        return interaction.reply({ content: '⚠️ No question at that position. Check `/ticket-form list`.', ephemeral: true });
      }
      const [removed] = data.ticket.formQuestions.splice(index, 1);
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: `🗑️ Removed: "${removed.question}"`, ephemeral: true });
    }

    if (sub === 'list') {
      if (!data.ticket.formQuestions.length) {
        return interaction.reply({ content: 'No form questions configured yet. Use `/ticket-form add`.', ephemeral: true });
      }
      const lines = data.ticket.formQuestions.map((q, i) => `${i + 1}. **${q.question}** _(${q.style}${q.required ? ', required' : ', optional'})_`);
      return interaction.reply({ content: lines.join('\n'), ephemeral: true });
    }

    if (sub === 'clear') {
      data.ticket.formQuestions = [];
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '🗑️ Cleared all form questions.', ephemeral: true });
    }
  },
};
