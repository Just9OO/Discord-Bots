const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-staff')
    .setDescription('Manage which roles are ticket staff')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a role as ticket staff')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to add as ticket staff').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a role from ticket staff')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List current ticket staff roles')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'add') {
      const role = interaction.options.getRole('role');
      if (role.id === interaction.guildId) {
        return interaction.reply({ content: '⚠️ You can\'t use @everyone as a staff role.', ephemeral: true });
      }
      if (data.ticket.staffRoleIds.includes(role.id)) {
        return interaction.reply({ content: `⚠️ **${role.name}** is already ticket staff.`, ephemeral: true });
      }
      data.ticket.staffRoleIds.push(role.id);
      saveGuildData(interaction.guildId, data);
      return interaction.reply({
        content: `✅ **${role.name}** is now ticket staff. They'll be able to see new tickets, get mentioned when one opens, and (if claiming is enabled via \`/ticket-claim enable\`) can claim tickets.`,
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role');
      const before = data.ticket.staffRoleIds.length;
      data.ticket.staffRoleIds = data.ticket.staffRoleIds.filter(id => id !== role.id);
      saveGuildData(interaction.guildId, data);
      if (before === data.ticket.staffRoleIds.length) {
        return interaction.reply({ content: `⚠️ **${role.name}** wasn't a ticket staff role.`, ephemeral: true });
      }
      return interaction.reply({ content: `🗑️ Removed **${role.name}** from ticket staff.`, ephemeral: true });
    }

    if (sub === 'list') {
      if (!data.ticket.staffRoleIds.length) {
        return interaction.reply({ content: 'No ticket staff roles configured yet. Use `/ticket-staff add`.', ephemeral: true });
      }
      return interaction.reply({ content: data.ticket.staffRoleIds.map(id => `<@&${id}>`).join('\n'), ephemeral: true });
    }
  },
};
