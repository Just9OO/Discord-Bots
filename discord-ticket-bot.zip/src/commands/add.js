const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildData } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('Add a user to the current ticket')
    .addUserOption(opt => opt.setName('user').setDescription('User to add to this ticket').setRequired(true)),

  async execute(interaction) {
    const { guild, channel, member } = interaction;
    const data = getGuildData(guild.id);
    const ticket = data.activeTickets[channel.id];

    if (!ticket) {
      return interaction.reply({ content: '⚠️ This command only works inside an open ticket channel.', ephemeral: true });
    }

    const isStaff = member.permissions.has(PermissionFlagsBits.Administrator)
      || data.ticket.staffRoleIds.some(id => member.roles.cache.has(id));
    if (!isStaff) {
      return interaction.reply({ content: '⚠️ Only ticket staff or admins can add people to a ticket.', ephemeral: true });
    }

    const user = interaction.options.getUser('user');
    await channel.permissionOverwrites.edit(user.id, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
    });

    return interaction.reply({ content: `✅ Added ${user} to this ticket.` });
  },
};
