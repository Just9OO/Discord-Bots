const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');
const { baseEmbed } = require('../utils/embeds');

function parseColor(input) {
  if (!input) return 0x5865f2;
  const n = parseInt(input.replace('#', ''), 16);
  return Number.isNaN(n) ? 0x5865f2 : n;
}

const CUSTOM_ID_BY_TYPE = {
  button: 'ticket_open_button',
  form: 'ticket_open_form',
  sidebar: 'ticket_open_sidebar',
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Configure and manage the ticket system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('panel')
        .setDescription('Send the ticket opening panel to a channel')
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to post the panel in').setRequired(true).addChannelTypes(ChannelType.GuildText))
        .addStringOption(opt =>
          opt.setName('type').setDescription('How users open a ticket from this panel').setRequired(true)
            .addChoices(
              { name: 'Regular Button Open', value: 'button' },
              { name: 'Form Open (fill out questions first)', value: 'form' },
              { name: 'Sidebar Open (pick a category from a menu)', value: 'sidebar' },
            ))
        .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(true))
        .addStringOption(opt => opt.setName('description').setDescription('Embed description').setRequired(true))
        .addStringOption(opt => opt.setName('color').setDescription('Hex color, e.g. #5865F2'))
        .addStringOption(opt => opt.setName('button_label').setDescription('Text on the Open Ticket button'))
        .addStringOption(opt => opt.setName('button_emoji').setDescription('Emoji on the Open Ticket button')))
    .addSubcommand(sub =>
      sub.setName('embed')
        .setDescription('Set the custom embed sent inside newly opened ticket channels')
        .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(true))
        .addStringOption(opt => opt.setName('description').setDescription('Embed description').setRequired(true))
        .addStringOption(opt => opt.setName('color').setDescription('Hex color, e.g. #5865F2'))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'panel') {
      const channel = interaction.options.getChannel('channel');
      const type = interaction.options.getString('type');
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const color = parseColor(interaction.options.getString('color'));
      const label = interaction.options.getString('button_label') || 'Open Ticket';
      const emoji = interaction.options.getString('button_emoji');

      if (type === 'form' && data.ticket.formQuestions.length === 0) {
        return interaction.reply({ content: '⚠️ You picked "Form Open" but no form questions are configured yet. Add at least one with `/ticket-form add` first.', ephemeral: true });
      }
      if (type === 'sidebar' && data.ticket.sidebarOptions.length === 0) {
        return interaction.reply({ content: '⚠️ You picked "Sidebar Open" but no sidebar options are configured yet. Add at least one with `/ticket-option add` first.', ephemeral: true });
      }
      if ((type === 'button' || type === 'form') && data.ticket.categories.length === 0) {
        return interaction.reply({ content: '⚠️ No ticket categories are configured yet. Add one with `/ticket-category add` first.', ephemeral: true });
      }

      data.ticket.type = type;
      data.ticket.panelEmbed = { title, description, color, buttonLabel: label, buttonEmoji: emoji };
      saveGuildData(interaction.guildId, data);

      const embed = baseEmbed(color).setTitle(title).setDescription(description);
      const button = new ButtonBuilder().setCustomId(CUSTOM_ID_BY_TYPE[type]).setLabel(label).setStyle(ButtonStyle.Primary);
      if (emoji) button.setEmoji(emoji);
      const row = new ActionRowBuilder().addComponents(button);

      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ content: `✅ Ticket panel posted in ${channel} (type: **${type}**).`, ephemeral: true });
    }

    if (sub === 'embed') {
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const color = parseColor(interaction.options.getString('color'));
      data.ticket.ticketEmbed = { title, description, color };
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '✅ The ticket-opened embed template has been updated. It will be used the next time a ticket is created.', ephemeral: true });
    }
  },
};
