const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

function isValidWebhookUrl(url) {
  try {
    const u = new URL(url);
    return u.hostname === 'discord.com' || u.hostname === 'discordapp.com';
  } catch {
    return false;
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transcript')
    .setDescription('Configure automatic ticket transcripts')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('set')
        .setDescription('Set the webhook a transcript is sent to whenever a ticket is closed')
        .addStringOption(opt => opt.setName('webhook_url').setDescription('A Discord webhook URL').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Stop sending transcripts when tickets close'))
    .addSubcommand(sub =>
      sub.setName('show')
        .setDescription('Show whether a transcript webhook is configured')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'set') {
      const url = interaction.options.getString('webhook_url');
      if (!isValidWebhookUrl(url)) {
        return interaction.reply({ content: '⚠️ That doesn\'t look like a Discord webhook URL. Create one in a channel\'s Integrations → Webhooks settings and paste the URL here.', ephemeral: true });
      }
      data.ticket.transcriptWebhookUrl = url;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '✅ Transcript webhook set. A transcript will be sent there every time a ticket is closed.', ephemeral: true });
    }

    if (sub === 'disable') {
      data.ticket.transcriptWebhookUrl = null;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '🚫 Automatic transcripts disabled.', ephemeral: true });
    }

    if (sub === 'show') {
      return interaction.reply({
        content: data.ticket.transcriptWebhookUrl ? '✅ A transcript webhook is configured.' : 'No transcript webhook configured. Use `/transcript set`.',
        ephemeral: true,
      });
    }
  },
};
