const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-log')
    .setDescription('Configure the channel ticket-closed events are logged to')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('set')
        .setDescription('Set the channel ticket closures are logged to')
        .addChannelOption(opt => opt.setName('channel').setDescription('Log channel').setRequired(true).addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(sub =>
      sub.setName('disable')
        .setDescription('Stop logging ticket closures'))
    .addSubcommand(sub =>
      sub.setName('show')
        .setDescription('Show the currently configured ticket log channel')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      data.ticket.logChannelId = channel.id;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: `✅ Ticket closures will now be logged to ${channel}.`, ephemeral: true });
    }

    if (sub === 'disable') {
      data.ticket.logChannelId = null;
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: '🚫 Ticket closure logging disabled.', ephemeral: true });
    }

    if (sub === 'show') {
      return interaction.reply({
        content: data.ticket.logChannelId ? `Ticket closures are logged to <#${data.ticket.logChannelId}>.` : 'No ticket log channel configured. Use `/ticket-log set`.',
        ephemeral: true,
      });
    }
  },
};
