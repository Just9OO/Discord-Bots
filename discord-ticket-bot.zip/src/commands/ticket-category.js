const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildData, saveGuildData } = require('../database');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-category')
    .setDescription('Manage which categories new tickets are created under')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand(sub =>
      sub.setName('add')
        .setDescription('Add a category tickets can be created under (used as overflow when others are full)')
        .addChannelOption(opt => opt.setName('category').setDescription('Category channel').setRequired(true).addChannelTypes(ChannelType.GuildCategory)))
    .addSubcommand(sub =>
      sub.setName('remove')
        .setDescription('Remove a category from the ticket pool')
        .addChannelOption(opt => opt.setName('category').setDescription('Category channel').setRequired(true).addChannelTypes(ChannelType.GuildCategory)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List categories currently used for tickets')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand(false);
    if (!sub) {
      return interaction.reply({ content: '⚠️ Please pick a subcommand for this command (e.g. type the command name and choose one from the list Discord shows you).', ephemeral: true });
    }
    const data = getGuildData(interaction.guildId);

    if (sub === 'add') {
      const category = interaction.options.getChannel('category');
      if (data.ticket.categories.includes(category.id)) {
        return interaction.reply({ content: `⚠️ **${category.name}** is already in the ticket category pool.`, ephemeral: true });
      }
      data.ticket.categories.push(category.id);
      saveGuildData(interaction.guildId, data);
      return interaction.reply({ content: `✅ Added **${category.name}** to the ticket category pool (position ${data.ticket.categories.length}). If a category fills up (50 channels), the bot automatically moves to the next one in the list.`, ephemeral: true });
    }

    if (sub === 'remove') {
      const category = interaction.options.getChannel('category');
      const before = data.ticket.categories.length;
      data.ticket.categories = data.ticket.categories.filter(id => id !== category.id);
      saveGuildData(interaction.guildId, data);
      if (before === data.ticket.categories.length) {
        return interaction.reply({ content: `⚠️ **${category.name}** wasn't in the ticket category pool.`, ephemeral: true });
      }
      return interaction.reply({ content: `🗑️ Removed **${category.name}** from the ticket category pool.`, ephemeral: true });
    }

    if (sub === 'list') {
      if (!data.ticket.categories.length) {
        return interaction.reply({ content: 'No ticket categories configured yet. Use `/ticket-category add`.', ephemeral: true });
      }
      const lines = data.ticket.categories.map((id, i) => `${i + 1}. <#${id}>`);
      return interaction.reply({ content: lines.join('\n'), ephemeral: true });
    }
  },
};
