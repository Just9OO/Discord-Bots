require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

// Registers all slash commands with Discord. Safe to call every time the bot
// starts — it's a single "replace all commands" call, not a per-command action,
// so it won't get you rate-limited and it won't create duplicates.
async function deployCommands() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    console.warn('⚠️ Skipping command deployment: DISCORD_TOKEN or CLIENT_ID is missing from the environment.');
    return;
  }

  const commands = [];
  const commandsPath = path.join(__dirname, 'commands');
  for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
    const command = require(path.join(commandsPath, file));
    commands.push(command.data.toJSON());
  }

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    if (process.env.GUILD_ID) {
      await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands },
      );
      console.log(`✅ Deployed ${commands.length} guild slash commands (instant).`);
    } else {
      await rest.put(
        Routes.applicationCommands(process.env.CLIENT_ID),
        { body: commands },
      );
      console.log(`✅ Deployed ${commands.length} global slash commands (can take up to 1 hour to appear everywhere).`);
    }
  } catch (err) {
    console.error('❌ Failed to deploy slash commands:', err.message);
  }
}

module.exports = { deployCommands };
