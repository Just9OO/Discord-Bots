const {
  handleOpenButton, handleOpenFormShowModal, handleFormSubmit,
  handleOpenSidebarShowMenu, handleSidebarSelect,
  handleClaim, handleClose, handleDelete,
} = require('../handlers/ticketHandler');

async function handleError(interaction, err) {
  console.error(err);
  const payload = { content: '❌ Something went wrong handling that.', ephemeral: true };
  if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
  else await interaction.reply(payload).catch(() => {});
}

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(err);
        const payload = { content: '❌ There was an error executing this command.', ephemeral: true };
        if (interaction.replied || interaction.deferred) await interaction.followUp(payload).catch(() => {});
        else await interaction.reply(payload).catch(() => {});
      }
      return;
    }

    if (interaction.isButton()) {
      try {
        if (interaction.customId === 'ticket_open_button') return await handleOpenButton(interaction);
        if (interaction.customId === 'ticket_open_form') return await handleOpenFormShowModal(interaction);
        if (interaction.customId === 'ticket_open_sidebar') return await handleOpenSidebarShowMenu(interaction);
        if (interaction.customId === 'ticket_claim') return await handleClaim(interaction);
        if (interaction.customId === 'ticket_close') return await handleClose(interaction);
        if (interaction.customId === 'ticket_delete') return await handleDelete(interaction);
      } catch (err) {
        await handleError(interaction, err);
      }
      return;
    }

    if (interaction.isModalSubmit()) {
      try {
        if (interaction.customId === 'ticket_form_modal') return await handleFormSubmit(interaction);
      } catch (err) {
        await handleError(interaction, err);
      }
      return;
    }

    if (interaction.isStringSelectMenu()) {
      try {
        if (interaction.customId === 'ticket_sidebar_select') return await handleSidebarSelect(interaction);
      } catch (err) {
        await handleError(interaction, err);
      }
    }
  },
};
