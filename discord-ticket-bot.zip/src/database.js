const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function filePath(guildId) {
  return path.join(DATA_DIR, `${guildId}.json`);
}

function defaultData() {
  return {
    ticket: {
      type: 'button', // 'button' | 'form' | 'sidebar' — set by the most recent /ticket panel
      panelEmbed: null,
      ticketEmbed: null,
      categories: [], // used by the 'button' and 'form' panel types (pool + overflow)
      formQuestions: [], // used by the 'form' panel type: [{ question, style, required, placeholder }]
      sidebarOptions: [], // used by the 'sidebar' panel type: [{ label, description, emoji, categoryId }]
      staffRoleIds: [], // roles that can see/claim tickets and get mentioned on open
      claim: { enabled: false },
      transcriptWebhookUrl: null,
      logChannelId: null, // set via /ticket-log
      counter: 0,
    },
    activeTickets: {},
  };
}

const cache = new Map();
const dirty = new Set();

function getGuildData(guildId) {
  if (cache.has(guildId)) return cache.get(guildId);
  const fp = filePath(guildId);
  let data;
  if (fs.existsSync(fp)) {
    try {
      const raw = JSON.parse(fs.readFileSync(fp, 'utf8'));
      const def = defaultData();
      data = { ...def, ...raw };
      data.ticket = { ...def.ticket, ...(raw.ticket || {}) };
      data.ticket.claim = { ...def.ticket.claim, ...((raw.ticket || {}).claim || {}) };
      data.ticket.categories = raw.ticket?.categories || [];
      data.ticket.formQuestions = raw.ticket?.formQuestions || [];
      data.ticket.sidebarOptions = raw.ticket?.sidebarOptions || [];
      data.ticket.staffRoleIds = raw.ticket?.staffRoleIds || [];
      data.activeTickets = raw.activeTickets || {};
    } catch (e) {
      data = defaultData();
    }
  } else {
    data = defaultData();
  }
  cache.set(guildId, data);
  return data;
}

// Immediate write — use for config commands (infrequent, should never be lost).
function saveGuildData(guildId, data) {
  cache.set(guildId, data);
  fs.writeFileSync(filePath(guildId), JSON.stringify(data, null, 2));
  dirty.delete(guildId);
}

// Deferred write — kept for parity/future use; not currently on any hot path
// now that leveling (the original reason for batching) has been removed.
function saveGuildDataThrottled(guildId, data) {
  cache.set(guildId, data);
  dirty.add(guildId);
}

function flushDirty() {
  for (const guildId of dirty) {
    const data = cache.get(guildId);
    if (!data) continue;
    try {
      fs.writeFileSync(filePath(guildId), JSON.stringify(data, null, 2));
    } catch (err) {
      console.error(`Failed to flush data for guild ${guildId}:`, err);
    }
  }
  dirty.clear();
}

module.exports = { getGuildData, saveGuildData, saveGuildDataThrottled, flushDirty };
