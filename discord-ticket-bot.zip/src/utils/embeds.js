const { EmbedBuilder } = require('discord.js');

function baseEmbed(color = 0x5865f2) {
  return new EmbedBuilder().setColor(color).setTimestamp();
}

module.exports = { baseEmbed };
