const {
  ChannelType, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder,
  EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder,
  WebhookClient,
} = require('discord.js');
const { createTranscript } = require('discord-html-transcripts');
const { getGuildData, saveGuildData } = require('../database');
const { baseEmbed } = require('../utils/embeds');

function pickCategory(guild, categoryIds) {
  for (const id of categoryIds) {
    const cat = guild.channels.cache.get(id);
    if (cat && cat.type === ChannelType.GuildCategory) {
      const childCount = guild.channels.cache.filter(c => c.parentId === id).size;
      if (childCount < 50) return cat;
    }
  }
  return null;
}

async function logToChannel(guild, embed) {
  const data = getGuildData(guild.id);
  const channelId = data.ticket.logChannelId;
  if (!channelId) return;
  const channel = guild.channels.cache.get(channelId);
  if (channel) channel.send({ embeds: [embed] }).catch(() => {});
}

function buildStaffOverwrites(guild, staffRoleIds, claimEnabled) {
  return staffRoleIds
    .filter(roleId => guild.roles.cache.has(roleId))
    .map(roleId => ({
      id: roleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
      deny: claimEnabled ? [PermissionFlagsBits.SendMessages] : [],
    }));
}

function findOpenTicketByUser(data, userId) {
  return Object.entries(data.activeTickets).find(([, t]) => t.userId === userId);
}

// Shared by all three panel types once a destination category has been decided.
async function createTicketChannel(interaction, category, extraFields = []) {
  const { guild, user } = interaction;
  const data = getGuildData(guild.id);

  const existing = findOpenTicketByUser(data, user.id);
  if (existing) {
    return { error: `⚠️ You already have an open ticket: <#${existing[0]}>` };
  }

  data.ticket.counter += 1;
  const ticketNumber = data.ticket.counter;

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
    { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
    ...buildStaffOverwrites(guild, data.ticket.staffRoleIds, data.ticket.claim.enabled),
  ];

  const channel = await guild.channels.create({
    name: `ticket-${ticketNumber.toString().padStart(4, '0')}`,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: overwrites,
  });

  data.activeTickets[channel.id] = {
    userId: user.id,
    claimedBy: null,
    createdAt: Date.now(),
    ticketNumber,
  };
  saveGuildData(guild.id, data);

  const tpl = data.ticket.ticketEmbed;
  const embed = tpl
    ? baseEmbed(tpl.color).setTitle(tpl.title).setDescription(tpl.description)
    : baseEmbed().setTitle('Support Ticket').setDescription(`Thanks for reaching out, ${user}. Support will be with you shortly.`);
  embed.addFields({ name: 'Opened by', value: `${user}`, inline: true });
  if (data.ticket.claim.enabled) embed.addFields({ name: 'Status', value: '🔓 Unclaimed', inline: true });
  if (extraFields.length) embed.addFields(...extraFields);

  const rowButtons = [];
  if (data.ticket.claim.enabled) {
    rowButtons.push(new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Success).setEmoji('🙋'));
  }
  rowButtons.push(new ButtonBuilder().setCustomId('ticket_close').setLabel('Close Ticket').setStyle(ButtonStyle.Danger).setEmoji('🔒'));
  const row = new ActionRowBuilder().addComponents(rowButtons);

  const staffMentions = data.ticket.staffRoleIds.map(id => `<@&${id}>`).join(' ');
  const content = staffMentions ? `${user} ${staffMentions}` : `${user}`;

  await channel.send({ content, embeds: [embed], components: [row] });
  return { channel };
}

// --- Regular Button Open ---
async function handleOpenButton(interaction) {
  const data = getGuildData(interaction.guild.id);
  if (!data.ticket.categories.length) {
    return interaction.reply({ content: '⚠️ No ticket categories have been configured yet. Ask an admin to run `/ticket-category add`.', ephemeral: true });
  }
  const category = pickCategory(interaction.guild, data.ticket.categories);
  if (!category) {
    return interaction.reply({ content: '⚠️ All configured ticket categories are full right now. Please contact an admin.', ephemeral: true });
  }
  await interaction.deferReply({ ephemeral: true });
  const result = await createTicketChannel(interaction, category);
  if (result.error) return interaction.editReply({ content: result.error });
  return interaction.editReply({ content: `✅ Ticket created: ${result.channel}` });
}

// --- Form Open: step 1, show the modal ---
async function handleOpenFormShowModal(interaction) {
  const data = getGuildData(interaction.guild.id);

  const existing = findOpenTicketByUser(data, interaction.user.id);
  if (existing) {
    return interaction.reply({ content: `⚠️ You already have an open ticket: <#${existing[0]}>`, ephemeral: true });
  }
  if (!data.ticket.categories.length) {
    return interaction.reply({ content: '⚠️ No ticket categories have been configured yet. Ask an admin to run `/ticket-category add`.', ephemeral: true });
  }
  if (!data.ticket.formQuestions.length) {
    return interaction.reply({ content: '⚠️ This ticket form has no questions configured. Ask an admin to run `/ticket-form add`.', ephemeral: true });
  }
  const category = pickCategory(interaction.guild, data.ticket.categories);
  if (!category) {
    return interaction.reply({ content: '⚠️ All configured ticket categories are full right now. Please contact an admin.', ephemeral: true });
  }

  const modal = new ModalBuilder().setCustomId('ticket_form_modal').setTitle('Open a Ticket');
  const rows = data.ticket.formQuestions.slice(0, 5).map((q, i) => {
    const input = new TextInputBuilder()
      .setCustomId(`q${i}`)
      .setLabel(q.question.slice(0, 45))
      .setStyle(q.style === 'paragraph' ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setRequired(q.required);
    if (q.placeholder) input.setPlaceholder(q.placeholder.slice(0, 100));
    return new ActionRowBuilder().addComponents(input);
  });
  modal.addComponents(...rows);
  await interaction.showModal(modal);
}

// --- Form Open: step 2, modal submitted ---
async function handleFormSubmit(interaction) {
  const data = getGuildData(interaction.guild.id);
  if (!data.ticket.categories.length) {
    return interaction.reply({ content: '⚠️ No ticket categories have been configured yet. Ask an admin to run `/ticket-category add`.', ephemeral: true });
  }
  const category = pickCategory(interaction.guild, data.ticket.categories);
  if (!category) {
    return interaction.reply({ content: '⚠️ All configured ticket categories are full right now. Please contact an admin.', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  const answers = data.ticket.formQuestions.slice(0, 5).map((q, i) => {
    let value = '';
    try { value = interaction.fields.getTextInputValue(`q${i}`); } catch { /* field wasn't shown */ }
    return { name: q.question.slice(0, 256), value: value ? value.slice(0, 1024) : '*No answer*' };
  });

  const result = await createTicketChannel(interaction, category, answers);
  if (result.error) return interaction.editReply({ content: result.error });
  return interaction.editReply({ content: `✅ Ticket created: ${result.channel}` });
}

// --- Sidebar Open: step 1, show the select menu ---
async function handleOpenSidebarShowMenu(interaction) {
  const data = getGuildData(interaction.guild.id);

  const existing = findOpenTicketByUser(data, interaction.user.id);
  if (existing) {
    return interaction.reply({ content: `⚠️ You already have an open ticket: <#${existing[0]}>`, ephemeral: true });
  }
  if (!data.ticket.sidebarOptions.length) {
    return interaction.reply({ content: '⚠️ No sidebar options have been configured yet. Ask an admin to run `/ticket-option add`.', ephemeral: true });
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId('ticket_sidebar_select')
    .setPlaceholder('Choose what you need help with...')
    .addOptions(data.ticket.sidebarOptions.slice(0, 25).map((o, i) => {
      const opt = { label: o.label.slice(0, 100), value: String(i) };
      if (o.description) opt.description = o.description.slice(0, 100);
      if (o.emoji) opt.emoji = o.emoji;
      return opt;
    }));
  const row = new ActionRowBuilder().addComponents(menu);
  return interaction.reply({ content: 'Select what you need help with:', components: [row], ephemeral: true });
}

// --- Sidebar Open: step 2, option selected ---
async function handleSidebarSelect(interaction) {
  const data = getGuildData(interaction.guild.id);
  const index = parseInt(interaction.values[0], 10);
  const option = data.ticket.sidebarOptions[index];
  if (!option) {
    return interaction.update({ content: '⚠️ That option no longer exists. Try opening a new ticket.', components: [] });
  }

  const category = interaction.guild.channels.cache.get(option.categoryId);
  if (!category) {
    return interaction.update({ content: '⚠️ The category for that option no longer exists. Contact an admin.', components: [] });
  }
  const childCount = interaction.guild.channels.cache.filter(c => c.parentId === category.id).size;
  if (childCount >= 50) {
    return interaction.update({ content: '⚠️ That category is full right now. Please contact an admin.', components: [] });
  }

  await interaction.update({ content: '⏳ Creating your ticket...', components: [] });

  const result = await createTicketChannel(interaction, category, [{ name: 'Category', value: option.label }]);
  if (result.error) return interaction.editReply({ content: result.error });
  return interaction.editReply({ content: `✅ Ticket created: ${result.channel}` });
}

async function handleClaim(interaction) {
  const { guild, member, channel } = interaction;
  const data = getGuildData(guild.id);
  const ticket = data.activeTickets[channel.id];
  if (!ticket) return interaction.reply({ content: '⚠️ This is not an active ticket channel.', ephemeral: true });

  const claim = data.ticket.claim;
  if (!claim.enabled) return interaction.reply({ content: '⚠️ Claiming is not enabled on this server.', ephemeral: true });
  const isStaff = data.ticket.staffRoleIds.some(id => member.roles.cache.has(id));
  if (!isStaff) {
    return interaction.reply({ content: '⚠️ You do not have a ticket staff role.', ephemeral: true });
  }
  if (ticket.claimedBy) {
    return interaction.reply({ content: `⚠️ This ticket has already been claimed by <@${ticket.claimedBy}>.`, ephemeral: true });
  }

  ticket.claimedBy = member.id;
  saveGuildData(guild.id, data);

  // Only the claimer may now talk; the rest of ticket staff stays denied.
  await channel.permissionOverwrites.edit(member.id, {
    ViewChannel: true,
    SendMessages: true,
    ReadMessageHistory: true,
  });

  const message = interaction.message;
  const oldEmbed = message.embeds[0];
  const embed = oldEmbed ? EmbedBuilder.from(oldEmbed) : baseEmbed();
  const fields = (oldEmbed?.fields ?? []).filter(f => f.name !== 'Status');
  fields.push({ name: 'Status', value: `🔒 Claimed by ${member}`, inline: true });
  embed.setFields(fields);

  const oldComponents = message.components[0]?.components ?? [];
  const newComponents = oldComponents.map(c => {
    if (c.customId === 'ticket_claim') {
      return ButtonBuilder.from(c).setDisabled(true).setLabel(`Claimed by ${member.user.username}`);
    }
    return ButtonBuilder.from(c);
  });
  const newRow = new ActionRowBuilder().addComponents(newComponents);

  await message.edit({ embeds: [embed], components: [newRow] });
  return interaction.reply({ content: '✅ You claimed this ticket. Other staff can no longer send messages here until it is closed.', ephemeral: true });
}

async function sendTranscript(channel, guild) {
  const data = getGuildData(guild.id);
  if (!data.ticket.transcriptWebhookUrl) return;
  try {
    const attachment = await createTranscript(channel, {
      filename: `transcript-${channel.name}.html`,
      saveImages: false,
      poweredBy: false,
    });
    const webhookClient = new WebhookClient({ url: data.ticket.transcriptWebhookUrl });
    await webhookClient.send({ content: `📄 Transcript for **#${channel.name}**`, files: [attachment] });
  } catch (err) {
    console.error(`Failed to send transcript for #${channel.name}:`, err.message);
  }
}

// Closing a ticket no longer deletes it: the channel is locked (staff/opener can no
// longer send messages) and renamed to `closed-...`, with a Delete button to remove
// it permanently later. A transcript is generated and sent to the configured webhook.
async function handleClose(interaction) {
  const { guild, channel, user } = interaction;
  const data = getGuildData(guild.id);
  const ticket = data.activeTickets[channel.id];
  if (!ticket) return interaction.reply({ content: '⚠️ This is not an active ticket channel.', ephemeral: true });

  await interaction.deferReply();

  await channel.permissionOverwrites.edit(ticket.userId, { SendMessages: false }).catch(() => {});
  if (ticket.claimedBy) {
    await channel.permissionOverwrites.edit(ticket.claimedBy, { SendMessages: false }).catch(() => {});
  }
  for (const roleId of data.ticket.staffRoleIds) {
    await channel.permissionOverwrites.edit(roleId, { SendMessages: false }).catch(() => {});
  }

  if (!channel.name.startsWith('closed-')) {
    await channel.setName(`closed-${channel.name}`.slice(0, 100)).catch(() => {});
  }

  const closeEmbed = baseEmbed(0xed4245)
    .setTitle('🔒 Ticket Closed')
    .addFields(
      { name: 'Opened by', value: `<@${ticket.userId}>`, inline: true },
      { name: 'Closed by', value: `${user}`, inline: true },
      { name: 'Claimed by', value: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'Nobody', inline: true },
    );
  const deleteRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_delete').setLabel('Delete Ticket').setStyle(ButtonStyle.Danger).setEmoji('🗑️'),
  );

  await interaction.editReply({ embeds: [closeEmbed], components: [deleteRow] });

  const logEmbed = baseEmbed(0xed4245)
    .setTitle('🔒 Ticket Closed')
    .addFields(
      { name: 'Ticket', value: `#${channel.name}`, inline: true },
      { name: 'Opened by', value: `<@${ticket.userId}>`, inline: true },
      { name: 'Closed by', value: `${user}`, inline: true },
      { name: 'Claimed by', value: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'Nobody', inline: true },
    );
  logToChannel(guild, logEmbed);

  delete data.activeTickets[channel.id];
  saveGuildData(guild.id, data);

  sendTranscript(channel, guild).catch(() => {});
}

async function handleDelete(interaction) {
  const { guild, channel, member } = interaction;
  const data = getGuildData(guild.id);
  const isStaff = member.permissions.has(PermissionFlagsBits.Administrator)
    || data.ticket.staffRoleIds.some(id => member.roles.cache.has(id));
  if (!isStaff) {
    return interaction.reply({ content: '⚠️ Only ticket staff or admins can delete a closed ticket.', ephemeral: true });
  }

  await interaction.reply({ content: '🗑️ Deleting this channel in 3 seconds...' });
  setTimeout(() => channel.delete().catch(() => {}), 3000);
}

module.exports = {
  logToChannel,
  handleOpenButton,
  handleOpenFormShowModal,
  handleFormSubmit,
  handleOpenSidebarShowMenu,
  handleSidebarSelect,
  handleClaim,
  handleClose,
  handleDelete,
};
