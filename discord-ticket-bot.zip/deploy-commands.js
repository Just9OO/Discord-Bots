// Manual/local use: `npm run deploy`. Not required if you're hosting somewhere
// that only runs `npm start` — index.js deploys commands automatically on boot.
const { deployCommands } = require('./src/deploy');
deployCommands();
