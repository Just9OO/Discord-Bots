// ==== Bot credentials ====
// You can fill these in directly (useful for hosts like Hiden Cloud where you
// can only run one start command and can't easily set environment variables),
// OR leave them blank and use a .env file / your host's environment variable
// panel instead — whichever is set wins if both are present.
//
// ⚠️ SECURITY: if you fill TOKEN in below, never share this file, upload it to
// a public GitHub repo, or paste its contents anywhere — including in chat
// with anyone, AI assistants included. Anyone with your token fully controls
// your bot. If it's ever exposed, reset it immediately in the Developer Portal. -Just9oo 
const TOKEN = '';      // <- Developer Portal -> Bot -> Token
const CLIENT_ID = '';  // <- Developer Portal -> General Information -> Application ID
const GUILD_ID = '';   // <- optional: a server ID for instant slash-command sync while testing

require('dotenv').config();
if (TOKEN) process.env.DISCORD_TOKEN = TOKEN;
if (CLIENT_ID) process.env.CLIENT_ID = CLIENT_ID;
if (GUILD_ID) process.env.GUILD_ID = GUILD_ID;

const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const { flushDirty } = require('./src/database');
const { deployCommands } = require('./src/deploy');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // needed for role/permission checks (staff roles, ticket overwrites)
  ],
  partials: [Partials.Channel],
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'src', 'commands');
for (const file of fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

const eventsPath = path.join(__dirname, 'src', 'events');
for (const file of fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
  else client.on(event.name, (...args) => event.execute(...args, client));
}

setInterval(flushDirty, 10000);

function shutdown() {
  flushDirty();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

// Auto-deploy slash commands on every boot. This means hosts that only let you
// run `npm start` (no shell access to run deploy-commands.js separately) still
// get commands registered — this is a safe, idempotent call every startup.
deployCommands().then(() => client.login(process.env.DISCORD_TOKEN));
